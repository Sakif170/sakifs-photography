export function formatDate(d: string) {
  return new Date(d + "T00:00:00Z").toLocaleDateString("bn-BD", {
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  });
}
