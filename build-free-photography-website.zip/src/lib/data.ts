import { db } from "@/db";
import { categories, photos } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

const DEFAULT_CATEGORIES = [
  { name: "প্রকৃতি", emoji: "🌿" },
  { name: "ক্যাম্পাস", emoji: "🏛️" },
  { name: "পোর্ট্রেট", emoji: "🧑" },
  { name: "স্ট্রিট", emoji: "🚶" },
  { name: "আকাশ ও মেঘ", emoji: "🌅" },
  { name: "ইভেন্ট", emoji: "🎉" },
];

async function selectCategories() {
  return db
    .select({
      id: categories.id,
      name: categories.name,
      emoji: categories.emoji,
      count: sql<number>`(select count(*)::int from ${photos} where ${photos.categoryId} = ${categories.id})`,
    })
    .from(categories)
    .orderBy(categories.id);
}

export async function getCategories() {
  let rows = await selectCategories();
  if (rows.length === 0) {
    await db.insert(categories).values(DEFAULT_CATEGORIES).onConflictDoNothing();
    rows = await selectCategories();
  }
  return rows;
}

export type PhotoItem = {
  id: number;
  title: string;
  description: string;
  location: string;
  categoryId: number | null;
  categoryName: string | null;
  takenAt: string;
};

export async function getPhotos(categoryId?: number): Promise<PhotoItem[]> {
  const q = db
    .select({
      id: photos.id,
      title: photos.title,
      description: photos.description,
      location: photos.location,
      categoryId: photos.categoryId,
      categoryName: categories.name,
      takenAt: photos.takenAt,
    })
    .from(photos)
    .leftJoin(categories, eq(photos.categoryId, categories.id))
    .orderBy(desc(photos.takenAt), desc(photos.id));

  return categoryId ? q.where(eq(photos.categoryId, categoryId)) : q;
}

export async function getStats() {
  const [r] = await db
    .select({
      total: sql<number>`count(*)::int`,
      days: sql<number>`count(distinct ${photos.takenAt})::int`,
    })
    .from(photos);
  return r;
}
