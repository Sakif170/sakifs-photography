import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sakif Bin Alam — ফটোগ্রাফি গ্যালারি",
  description: "ক্যাম্পাস, প্রকৃতি ও জীবনের প্রতিদিনের মুহূর্ত — সাকিফ বিন আলমের ফটোগ্রাফি সংগ্রহ।",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="bn">
      <body className="antialiased">
        <header className="sticky top-0 z-30 border-b border-[var(--line)] bg-[#0b0b0f]/80 backdrop-blur">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
            <Link href="/" className="flex items-center gap-2 text-lg font-bold tracking-tight">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-[var(--accent)] text-base text-black">📷</span>
              <span>
                Sakif <span className="text-[var(--accent)]">Frames</span>
              </span>
            </Link>
            <nav className="flex items-center gap-5 text-sm text-zinc-300">
              <Link href="/#gallery" className="hover:text-white">গ্যালারি</Link>
              <Link href="/#about" className="hover:text-white">পরিচিতি</Link>
              <Link href="/admin" className="rounded-lg border border-[var(--line)] px-3 py-1.5 hover:border-[var(--accent)] hover:text-white">
                আপলোড
              </Link>
            </nav>
          </div>
        </header>
        {children}
        <footer className="mt-20 border-t border-[var(--line)] py-8 text-center text-sm text-zinc-500">
          © {new Date().getFullYear()} Sakif Bin Alam · ইসলামী বিশ্ববিদ্যালয় · ফটোগ্রাফিক সোসাইটি
        </footer>
      </body>
    </html>
  );
}
