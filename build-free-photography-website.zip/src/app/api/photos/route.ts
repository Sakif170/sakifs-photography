import { db } from "@/db";
import { photos } from "@/db/schema";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MAX_SIZE = 15 * 1024 * 1024;
const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"];

export async function POST(req: Request) {
  if (!(await isAdmin())) {
    return Response.json({ ok: false, error: "অনুমতি নেই। আগে লগইন করুন।" }, { status: 401 });
  }

  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return Response.json({ ok: false, error: "কোনো ছবি পাওয়া যায়নি" }, { status: 400 });
    }
    if (!ALLOWED.includes(file.type)) {
      return Response.json({ ok: false, error: "শুধু JPG, PNG, WEBP, GIF বা AVIF ছবি দেয়া যাবে" }, { status: 400 });
    }
    if (file.size > MAX_SIZE) {
      return Response.json({ ok: false, error: "ছবির সাইজ ১৫MB এর বেশি হতে পারবে না" }, { status: 400 });
    }

    const title = String(form.get("title") ?? "").trim() || file.name.replace(/\.[^.]+$/, "") || "শিরোনামহীন";
    const description = String(form.get("description") ?? "").trim();
    const location = String(form.get("location") ?? "").trim();
    const catRaw = Number(form.get("categoryId"));
    const categoryId = Number.isInteger(catRaw) && catRaw > 0 ? catRaw : null;
    const takenRaw = String(form.get("takenAt") ?? "");
    const takenAt = /^\d{4}-\d{2}-\d{2}$/.test(takenRaw) ? takenRaw : new Date().toISOString().slice(0, 10);

    const buf = Buffer.from(await file.arrayBuffer());
    const [row] = await db
      .insert(photos)
      .values({
        title,
        description,
        location,
        categoryId,
        takenAt,
        mimeType: file.type,
        size: buf.length,
        data: buf,
      })
      .returning({ id: photos.id });

    return Response.json({ ok: true, id: row.id });
  } catch {
    return Response.json({ ok: false, error: "আপলোড ব্যর্থ হয়েছে, আবার চেষ্টা করুন" }, { status: 500 });
  }
}
