import { db } from "@/db";
import { photos } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const num = Number(id);
  if (!Number.isInteger(num)) return new Response("Not found", { status: 404 });

  const [row] = await db
    .select({ data: photos.data, mimeType: photos.mimeType, title: photos.title })
    .from(photos)
    .where(eq(photos.id, num))
    .limit(1);

  if (!row) return new Response("Not found", { status: 404 });

  const headers: Record<string, string> = {
    "Content-Type": row.mimeType,
    "Content-Length": String(row.data.length),
    "Cache-Control": "public, max-age=31536000, immutable",
  };

  const url = new URL(req.url);
  if (url.searchParams.get("download") === "1") {
    const ext = row.mimeType.split("/")[1] ?? "jpg";
    headers["Content-Disposition"] = `attachment; filename="photo-${num}.${ext}"`;
  }

  return new Response(new Uint8Array(row.data), { headers });
}
