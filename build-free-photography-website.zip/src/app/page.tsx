import Gallery from "@/components/Gallery";
import { getCategories, getPhotos, getStats } from "@/lib/data";
import Link from "next/link";

export const dynamic = "force-dynamic";

const bn = (n: number) => n.toLocaleString("bn-BD");

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ cat?: string }>;
}) {
  const { cat } = await searchParams;
  const catId = Number(cat);
  const activeCat = Number.isInteger(catId) && catId > 0 ? catId : undefined;

  const [cats, photos, stats] = await Promise.all([getCategories(), getPhotos(activeCat), getStats()]);
  const totalAll = cats.reduce((s, c) => s + c.count, 0);

  return (
    <main>
      <section className="hero-bg border-b border-[var(--line)]">
        <div className="mx-auto max-w-7xl px-5 py-20 md:py-28">
          <p className="text-sm uppercase tracking-[0.25em] text-[var(--accent)]">Photography Journal</p>
          <h1 className="mt-4 max-w-3xl text-4xl font-bold leading-tight md:text-6xl">
            প্রতিদিনের <span className="text-[var(--accent)]">আলো</span>, <br />
            ফ্রেমে বন্দি মুহূর্ত।
          </h1>
          <p className="mt-5 max-w-xl text-zinc-300">
            আমি সাকিফ বিন আলম — ইসলামী বিশ্ববিদ্যালয়ের শিক্ষার্থী ও ক্যাম্পাস ফটোগ্রাফিক সোসাইটির অর্গানাইজিং সেক্রেটারি। এখানে আমার তোলা ছবিগুলো ক্যাটাগরি অনুযায়ী সাজানো আছে।
          </p>
          <div className="mt-8 flex flex-wrap gap-8 text-sm">
            <div>
              <div className="text-3xl font-bold">{bn(stats.total)}</div>
              <div className="text-zinc-400">মোট ছবি</div>
            </div>
            <div>
              <div className="text-3xl font-bold">{bn(cats.length)}</div>
              <div className="text-zinc-400">ক্যাটাগরি</div>
            </div>
            <div>
              <div className="text-3xl font-bold">{bn(stats.days)}</div>
              <div className="text-zinc-400">ছবি তোলার দিন</div>
            </div>
          </div>
          <div className="mt-8 flex gap-3">
            <Link href="#gallery" className="btn">ছবি দেখুন ↓</Link>
            <Link href="/admin" className="btn btn-ghost">নতুন ছবি আপলোড</Link>
          </div>
        </div>
      </section>

      <section id="gallery" className="mx-auto max-w-7xl scroll-mt-20 px-5 pt-12">
        <div className="mb-8 flex flex-wrap gap-2">
          <Link
            href="/#gallery"
            className={`rounded-full border px-4 py-1.5 text-sm transition ${
              !activeCat
                ? "border-[var(--accent)] bg-[var(--accent)] font-semibold text-black"
                : "border-[var(--line)] text-zinc-300 hover:border-zinc-500"
            }`}
          >
            সব ({bn(totalAll)})
          </Link>
          {cats.map((c) => (
            <Link
              key={c.id}
              href={`/?cat=${c.id}#gallery`}
              className={`rounded-full border px-4 py-1.5 text-sm transition ${
                activeCat === c.id
                  ? "border-[var(--accent)] bg-[var(--accent)] font-semibold text-black"
                  : "border-[var(--line)] text-zinc-300 hover:border-zinc-500"
              }`}
            >
              {c.emoji} {c.name} ({bn(c.count)})
            </Link>
          ))}
        </div>

        <Gallery key={activeCat ?? "all"} photos={photos} />
      </section>

      <section id="about" className="mx-auto mt-24 max-w-3xl scroll-mt-20 px-5 text-center">
        <h2 className="text-2xl font-bold">পরিচিতি</h2>
        <p className="mt-4 leading-relaxed text-zinc-300">
          ফটোগ্রাফি আমার নেশা। ক্যাম্পাসের সকাল, নদীর ধার, আকাশের মেঘ কিংবা বন্ধুদের হাসি — যা-ই চোখে পড়ে, ফ্রেমে ধরে রাখি। ক্যাম্পাসের ফটোগ্রাফিক সোসাইটির অর্গানাইজিং সেক্রেটারি হিসেবে নতুন ফটোগ্রাফারদের সাথে শেখা ও শেখানোর আনন্দটাও ভাগ করে নিতে চাই।
        </p>
      </section>
    </main>
  );
}
