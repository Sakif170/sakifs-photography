"use server";

import { db } from "@/db";
import { categories, photos } from "@/db/schema";
import { checkPassword, clearAdminCookie, isAdmin, setAdminCookie } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export type ActionState = { error?: string; ok?: string } | null;

export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const pw = String(formData.get("password") ?? "");
  if (!checkPassword(pw)) return { error: "পাসওয়ার্ড ভুল হয়েছে" };
  await setAdminCookie();
  revalidatePath("/admin");
  return { ok: "লগইন সফল" };
}

export async function logoutAction() {
  await clearAdminCookie();
  revalidatePath("/admin");
  revalidatePath("/");
}

export async function createCategoryAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (!(await isAdmin())) return { error: "অনুমতি নেই" };
  const name = String(formData.get("name") ?? "").trim();
  const emoji = String(formData.get("emoji") ?? "").trim() || "📷";
  if (!name) return { error: "ক্যাটাগরির নাম লিখুন" };
  if (name.length > 40) return { error: "নাম খুব বড়" };
  try {
    await db.insert(categories).values({ name, emoji: emoji.slice(0, 8) });
  } catch {
    return { error: "এই নামের ক্যাটাগরি আগেই আছে" };
  }
  revalidatePath("/admin");
  revalidatePath("/");
  return { ok: "ক্যাটাগরি যোগ হয়েছে" };
}

export async function deleteCategoryAction(formData: FormData) {
  if (!(await isAdmin())) return;
  const id = Number(formData.get("id"));
  if (!Number.isInteger(id)) return;
  await db.delete(categories).where(eq(categories.id, id));
  revalidatePath("/admin");
  revalidatePath("/");
}

export async function deletePhotoAction(formData: FormData) {
  if (!(await isAdmin())) return;
  const id = Number(formData.get("id"));
  if (!Number.isInteger(id)) return;
  await db.delete(photos).where(eq(photos.id, id));
  revalidatePath("/admin");
  revalidatePath("/");
}

export async function refreshGalleryAction() {
  revalidatePath("/admin");
  revalidatePath("/");
}
