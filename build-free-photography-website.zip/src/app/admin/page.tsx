import { deleteCategoryAction, deletePhotoAction, logoutAction } from "@/app/actions";
import { CategoryForm, LoginForm } from "@/components/AdminForms";
import { formatDate } from "@/lib/format";
import UploadForm from "@/components/UploadForm";
import { isAdmin } from "@/lib/auth";
import { getCategories, getPhotos } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata = { title: "আপলোড ড্যাশবোর্ড — Sakif Frames" };

export default async function AdminPage() {
  if (!(await isAdmin())) {
    return (
      <main className="mx-auto grid min-h-[70vh] max-w-md place-items-center px-5">
        <div className="w-full rounded-2xl border border-[var(--line)] bg-[var(--card)] p-8">
          <div className="text-4xl">🔐</div>
          <h1 className="mt-3 text-2xl font-bold">অ্যাডমিন লগইন</h1>
          <p className="mb-6 mt-1 text-sm text-zinc-400">ছবি আপলোড ও ম্যানেজ করতে পাসওয়ার্ড দিন।</p>
          <LoginForm />
        </div>
      </main>
    );
  }

  const [cats, photos] = await Promise.all([getCategories(), getPhotos()]);

  return (
    <main className="mx-auto max-w-7xl px-5 py-10">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">আপলোড ড্যাশবোর্ড</h1>
          <p className="text-sm text-zinc-400">স্বাগতম, সাকিফ! আজকের ছবিগুলো আপলোড করুন।</p>
        </div>
        <form action={logoutAction}>
          <button className="btn btn-ghost">লগআউট</button>
        </form>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <section className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-6 lg:col-span-2">
          <h2 className="mb-4 text-lg font-semibold">নতুন ছবি আপলোড</h2>
          <UploadForm categories={cats} />
        </section>

        <section className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-6">
          <h2 className="mb-4 text-lg font-semibold">ক্যাটাগরি</h2>
          <ul className="mb-5 space-y-2">
            {cats.map((c) => (
              <li key={c.id} className="flex items-center justify-between rounded-lg bg-[#0f0f15] px-3 py-2 text-sm">
                <span>
                  {c.emoji} {c.name} <span className="text-zinc-500">({c.count})</span>
                </span>
                <form action={deleteCategoryAction}>
                  <input type="hidden" name="id" value={c.id} />
                  <button className="text-xs text-red-400 hover:underline" title="ক্যাটাগরি মুছুন (ছবি থাকবে)">
                    মুছুন
                  </button>
                </form>
              </li>
            ))}
          </ul>
          <CategoryForm />
        </section>
      </div>

      <section className="mt-10">
        <h2 className="mb-4 text-lg font-semibold">সব ছবি ({photos.length})</h2>
        {photos.length === 0 ? (
          <p className="text-zinc-500">এখনো কোনো ছবি আপলোড হয়নি।</p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {photos.map((p) => (
              <div key={p.id} className="overflow-hidden rounded-xl border border-[var(--line)] bg-[var(--card)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/api/photos/${p.id}`} alt={p.title} loading="lazy" className="aspect-square w-full object-cover" />
                <div className="space-y-1 p-3">
                  <div className="truncate text-sm font-medium">{p.title}</div>
                  <div className="truncate text-xs text-zinc-500">
                    {p.categoryName ?? "ক্যাটাগরি নেই"} · {formatDate(p.takenAt)}
                  </div>
                  <form action={deletePhotoAction}>
                    <input type="hidden" name="id" value={p.id} />
                    <button className="text-xs text-red-400 hover:underline">🗑 মুছুন</button>
                  </form>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
