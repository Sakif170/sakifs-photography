"use client";

import { createCategoryAction, loginAction, type ActionState } from "@/app/actions";
import { useActionState, useEffect, useRef } from "react";

export function LoginForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(loginAction, null);
  return (
    <form action={action} className="space-y-4">
      <input
        type="password"
        name="password"
        className="input"
        placeholder="অ্যাডমিন পাসওয়ার্ড"
        required
        autoFocus
      />
      {state?.error && <p className="text-sm text-red-400">{state.error}</p>}
      <button className="btn w-full" disabled={pending}>
        {pending ? "যাচাই হচ্ছে…" : "লগইন"}
      </button>
    </form>
  );
}

export function CategoryForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(createCategoryAction, null);
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (state?.ok) ref.current?.reset();
  }, [state]);

  return (
    <form ref={ref} action={action} className="space-y-3">
      <div className="flex gap-2">
        <input name="emoji" className="input !w-16 text-center" placeholder="🙂" maxLength={8} />
        <input name="name" className="input" placeholder="নতুন ক্যাটাগরির নাম" required maxLength={40} />
      </div>
      {state?.error && <p className="text-sm text-red-400">{state.error}</p>}
      {state?.ok && <p className="text-sm text-emerald-400">{state.ok}</p>}
      <button className="btn btn-ghost" disabled={pending}>
        ＋ ক্যাটাগরি যোগ করুন
      </button>
    </form>
  );
}
