"use client";

import { refreshGalleryAction } from "@/app/actions";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

type Cat = { id: number; name: string; emoji: string };
type Result = { name: string; ok: boolean; msg?: string };

const MAX_DIM = 2560;

async function optimize(file: File): Promise<File> {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, MAX_DIM / Math.max(bmp.width, bmp.height));
    if (scale === 1 && file.size < 6 * 1024 * 1024) {
      bmp.close();
      return file;
    }
    const w = Math.round(bmp.width * scale);
    const h = Math.round(bmp.height * scale);
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bmp, 0, 0, w, h);
    bmp.close();
    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/jpeg", 0.88));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch {
    return file;
  }
}

export default function UploadForm({ categories }: { categories: Cat[] }) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [takenAt, setTakenAt] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<Result[]>([]);

  useEffect(() => {
    const d = new Date();
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    setTakenAt(local);
  }, []);

  useEffect(() => {
    const urls = files.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [files]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (files.length === 0) return;
    setBusy(true);
    setResults([]);
    setProgress(0);
    const out: Result[] = [];

    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      try {
        const optimized = await optimize(f);
        const fd = new FormData();
        fd.set("file", optimized);
        fd.set("title", files.length === 1 ? title : title ? `${title} ${i + 1}` : "");
        fd.set("description", description);
        fd.set("location", location);
        fd.set("categoryId", categoryId);
        fd.set("takenAt", takenAt);
        const res = await fetch("/api/photos", { method: "POST", body: fd });
        const json = await res.json().catch(() => ({ ok: false, error: "সার্ভার ত্রুটি" }));
        out.push({ name: f.name, ok: !!json.ok, msg: json.error });
      } catch {
        out.push({ name: f.name, ok: false, msg: "নেটওয়ার্ক সমস্যা" });
      }
      setProgress(i + 1);
      setResults([...out]);
    }

    setBusy(false);
    if (out.some((r) => r.ok)) {
      await refreshGalleryAction();
      router.refresh();
    }
    if (out.every((r) => r.ok)) {
      setFiles([]);
      setTitle("");
      setDescription("");
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-[var(--line)] bg-[#0f0f15] px-4 py-10 text-center transition hover:border-[var(--accent)]">
        <span className="text-4xl">📤</span>
        <span className="font-semibold">ছবি বেছে নিন (একসাথে অনেকগুলো দেয়া যাবে)</span>
        <span className="text-xs text-zinc-500">JPG, PNG, WEBP · বড় ছবি স্বয়ংক্রিয়ভাবে অপটিমাইজ হবে</span>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
        />
      </label>

      {previews.length > 0 && (
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
          {previews.map((u, i) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={u} src={u} alt={files[i]?.name ?? ""} className="aspect-square w-full rounded-lg object-cover" />
          ))}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-zinc-400">ক্যাটাগরি</label>
          <select className="input" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
            <option value="">— ক্যাটাগরি নেই —</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.emoji} {c.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm text-zinc-400">ছবি তোলার তারিখ</label>
          <input type="date" className="input" value={takenAt} onChange={(e) => setTakenAt(e.target.value)} required />
        </div>
        <div>
          <label className="mb-1 block text-sm text-zinc-400">শিরোনাম (ফাঁকা রাখলে ফাইলের নাম)</label>
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-zinc-400">স্থান</label>
          <input
            className="input"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="যেমন: ক্যাম্পাস লেক"
            maxLength={120}
          />
        </div>
      </div>
      <div>
        <label className="mb-1 block text-sm text-zinc-400">বর্ণনা (ঐচ্ছিক)</label>
        <textarea className="input" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={600} />
      </div>

      <button className="btn w-full sm:w-auto" disabled={busy || files.length === 0}>
        {busy ? `আপলোড হচ্ছে… ${progress}/${files.length}` : `আপলোড করুন${files.length ? ` (${files.length}টি)` : ""}`}
      </button>

      {results.length > 0 && (
        <ul className="space-y-1 text-sm">
          {results.map((r, i) => (
            <li key={i} className={r.ok ? "text-emerald-400" : "text-red-400"}>
              {r.ok ? "✓" : "✕"} {r.name} {r.msg ? `— ${r.msg}` : ""}
            </li>
          ))}
        </ul>
      )}
    </form>
  );
}
