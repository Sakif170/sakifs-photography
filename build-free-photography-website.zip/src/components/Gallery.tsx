"use client";

import { formatDate } from "@/lib/format";
import { useCallback, useEffect, useState } from "react";

export type GalleryPhoto = {
  id: number;
  title: string;
  description: string;
  location: string;
  categoryName: string | null;
  takenAt: string;
};



export default function Gallery({ photos }: { photos: GalleryPhoto[] }) {
  const [active, setActive] = useState<number | null>(null);

  const close = useCallback(() => setActive(null), []);
  const prev = useCallback(
    () => setActive((i) => (i === null ? i : (i - 1 + photos.length) % photos.length)),
    [photos.length],
  );
  const next = useCallback(
    () => setActive((i) => (i === null ? i : (i + 1) % photos.length)),
    [photos.length],
  );

  useEffect(() => {
    if (active === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [active, close, prev, next]);

  if (photos.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-[var(--line)] py-20 text-center text-zinc-400">
        <div className="text-5xl">🖼️</div>
        <p className="mt-3">এখানে এখনো কোনো ছবি নেই।</p>
      </div>
    );
  }

  const current = active !== null ? photos[active] : null;

  return (
    <>
      <div className="masonry">
        {photos.map((p, i) => (
          <button
            key={p.id}
            onClick={() => setActive(i)}
            className="group relative block w-full overflow-hidden rounded-xl bg-[var(--card)] text-left"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`/api/photos/${p.id}`}
              alt={p.title}
              loading="lazy"
              className="block w-full transition duration-500 group-hover:scale-[1.04]"
            />
            <div className="pointer-events-none absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/80 via-transparent to-transparent p-3 opacity-0 transition group-hover:opacity-100">
              <div className="font-semibold">{p.title}</div>
              <div className="text-xs text-zinc-300">
                {p.categoryName ? `${p.categoryName} · ` : ""}
                {formatDate(p.takenAt)}
              </div>
            </div>
          </button>
        ))}
      </div>

      {current && (
        <div
          className="fixed inset-0 z-50 flex flex-col bg-black/95"
          role="dialog"
          aria-modal="true"
          onClick={close}
        >
          <div className="flex items-center justify-between px-5 py-3" onClick={(e) => e.stopPropagation()}>
            <span className="text-sm text-zinc-400">
              {active! + 1} / {photos.length}
            </span>
            <div className="flex gap-2">
              <a
                href={`/api/photos/${current.id}?download=1`}
                className="rounded-lg border border-zinc-700 px-3 py-1.5 text-sm hover:border-[var(--accent)]"
              >
                ⬇ ডাউনলোড
              </a>
              <button
                onClick={close}
                className="rounded-lg border border-zinc-700 px-3 py-1.5 text-sm hover:border-[var(--accent)]"
              >
                ✕ বন্ধ
              </button>
            </div>
          </div>

          <div className="relative flex min-h-0 flex-1 items-center justify-center px-4">
            <button
              aria-label="আগের ছবি"
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              className="absolute left-3 z-10 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-xl hover:bg-white/20"
            >
              ‹
            </button>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`/api/photos/${current.id}`}
              alt={current.title}
              onClick={(e) => e.stopPropagation()}
              className="max-h-full max-w-full rounded-lg object-contain"
            />
            <button
              aria-label="পরের ছবি"
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              className="absolute right-3 z-10 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-xl hover:bg-white/20"
            >
              ›
            </button>
          </div>

          <div className="px-5 py-4 text-center" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-semibold">{current.title}</h3>
            <p className="mt-1 text-sm text-zinc-400">
              {current.categoryName ? `${current.categoryName} · ` : ""}
              {formatDate(current.takenAt)}
              {current.location ? ` · 📍 ${current.location}` : ""}
            </p>
            {current.description && <p className="mx-auto mt-2 max-w-2xl text-sm text-zinc-300">{current.description}</p>}
          </div>
        </div>
      )}
    </>
  );
}
